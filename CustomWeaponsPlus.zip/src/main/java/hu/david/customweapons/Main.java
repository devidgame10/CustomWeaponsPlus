package hu.david.customweapons;

import hu.david.customweapons.command.CWCommand;
import hu.david.customweapons.listeners.WeaponEventListener;
import hu.david.customweapons.service.WeaponService;
import hu.david.customweapons.storage.YamlStorage;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

/**
 * Main osztály — inicializálja a szolgáltatásokat: YamlStorage, WeaponService,
 * Vault-eket és regisztrálja a parancsokat és eventeket.
 *
 * Ez a verzió folytatja az 1. mérföldkőn kezdett munkát: itt regisztráljuk az
 * aszinkron YAML I/O réteget és a fegyver szolgáltatást.
 */
public class Main extends JavaPlugin {

    private Economy economy;
    private String detectedAuctionPlugin = null;

    // Szolgáltatások
    private YamlStorage yamlStorage;
    private WeaponService weaponService;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        // Logger szint beállítása konfigurációból
        Level logLevel = Level.INFO;
        try {
            String level = getConfig().getString("log-level", "INFO").toUpperCase();
            logLevel = Level.parse(level);
        } catch (Exception ignored) {}
        getLogger().setLevel(logLevel);

        // Vault hook (soft-hook)
        setupVault();

        // Aukciós plugin runtime detektálása (soft-hook)
        detectAuctionPlugin();

        // Adatkönyvtár létrehozása
        getDataFolder().mkdirs();

        // Inicializáljuk a YAML storage-t és betöltjük az adatokat aszinkron
        yamlStorage = new YamlStorage(this);
        yamlStorage.loadAllAsync(() -> {
            // Miután a YAML-ok betöltődtek, inicializáljuk a WeaponService
            weaponService = new WeaponService(this, yamlStorage);
            weaponService.loadWeaponsIntoMemory();

            // Regisztráljuk a parancsot és az eseményeket, miután a service készen áll
            getCommand("cw").setExecutor(new CWCommand(this, weaponService, yamlStorage));
            Bukkit.getPluginManager().registerEvents(new WeaponEventListener(this, weaponService, yamlStorage), this);

            getLogger().info("WeaponService inicializálva és események regisztrálva.");
        });

        getLogger().info("CustomWeaponsPlus engedélyezési folyamat elindítva...");
    }

    @Override
    public void onDisable() {
        // Mentjük az aktuális memóriában lévő per-player állapotokat aszinkron
        if (yamlStorage != null) {
            yamlStorage.saveAllPlayersAsync(() -> getLogger().info("Per-player adatok aszinkron mentése kész."));
        }
        getLogger().info("CustomWeaponsPlus leállítva.");
    }

    /**
     * Vault Economy inicializálása (soft-hook).
     */
    private void setupVault() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            getLogger().info("Vault nem található: Economy hook kihagyva.");
            return;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            getLogger().info("Vault telepítve, de Economy szolgáltatás nem érhető el.");
            return;
        }
        economy = rsp.getProvider();
        if (economy != null) {
            getLogger().info("Vault Economy sikeresen hook-olva.");
        } else {
            getLogger().info("Economy provider nem elérhető.");
        }
    }

    /**
     * Egyszerű runtime aukciós plugin detect (soft-hook).
     */
    private void detectAuctionPlugin() {
        String[] candidates = new String[]{"AuctionHouse", "CrazyAuctions", "UltimateAuctions"};
        for (String name : candidates) {
            if (getServer().getPluginManager().getPlugin(name) != null) {
                detectedAuctionPlugin = name;
                getLogger().info("Aukciós plugin detektálva: " + name);
                return;
            }
        }
        getLogger().info("Nincs aukciós plugin detektálva.");
    }

    /**
     * Getter a WeaponService-hez (null lehet, ha még nem inicializálódtak).
     */
    public WeaponService getWeaponService() {
        return weaponService;
    }
}

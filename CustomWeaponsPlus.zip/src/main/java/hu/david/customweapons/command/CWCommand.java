package hu.david.customweapons.command;

import hu.david.customweapons.Main;
import hu.david.customweapons.service.WeaponService;
import hu.david.customweapons.storage.YamlStorage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

/**
 * CWCommand — parancsok kezelése: give, addmodel, reload.
 *
 * A give most már a WeaponService-t használja a tényleges ItemStack létrehozásához.
 */
public class CWCommand implements CommandExecutor {

    private final Main plugin;
    private final WeaponService weaponService;
    private final YamlStorage storage;

    public CWCommand(Main plugin, WeaponService weaponService, YamlStorage storage) {
        this.plugin = plugin;
        this.weaponService = weaponService;
        this.storage = storage;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§6CustomWeaponsPlus §7- használat: /cw give <player> <weapon-id> [count]");
            return true;
        }
        String sub = args[0].toLowerCase();
        switch (sub) {
            case "give":
                if (!sender.hasPermission("cw.give") && !(sender instanceof Player && sender.isOp())) {
                    sender.sendMessage("§cNincs jogod /cw give használatához.");
                    return true;
                }
                if (args.length < 3) {
                    sender.sendMessage("§cHasználat: /cw give <player> <weapon-id> [count]");
                    return true;
                }
                String targetName = args[1];
                String weaponId = args[2];
                int count = 1;
                if (args.length >= 4) {
                    try {
                        count = Integer.parseInt(args[3]);
                    } catch (NumberFormatException e) {
                        sender.sendMessage("§cA count nem szám, használom az alapértéket 1.");
                    }
                }
                var target = Bukkit.getPlayerExact(targetName);
                if (target == null) {
                    sender.sendMessage("§cA játékos nincs online: " + targetName);
                    return true;
                }
                boolean ok = weaponService.giveWeapon(sender.getName(), target, weaponId, count);
                if (ok) sender.sendMessage("§aAdva " + count + "x " + weaponId + " -> " + targetName);
                else sender.sendMessage("§cFegyver azonosító nem található: " + weaponId);
                return true;

            case "addmodel":
                if (!sender.hasPermission("cw.admin") && !(sender instanceof Player && sender.isOp())) {
                    sender.sendMessage("§cNincs jogod /cw addmodel használatához.");
                    return true;
                }
                if (args.length < 3) {
                    sender.sendMessage("§cHasználat: /cw addmodel <id> <resourcepack-path>");
                    return true;
                }
                // Egyszerűen mentjük a weapons.yml-be (ha létezik a fegyver, seteljük a customModelData vagy modelPath mezőt)
                String id = args[1];
                String rpPath = args[2];
                var def = weaponService.getWeapon(id);
                if (def == null) {
                    sender.sendMessage("§cFegyver nem található: " + id);
                    return true;
                }
                // ideiglenes: customModelData tárolása helyett a "modelPath" specialAbility paramként (később külön mapping)
                def.addAbility("modelPath", Map.of("path", rpPath));
                weaponService.updateWeaponAndSave(def);
                sender.sendMessage("§aModel mapping hozzáadva: " + id + " -> " + rpPath);
                return true;

            case "reload":
                if (!sender.hasPermission("cw.admin") && !(sender instanceof Player && sender.isOp())) {
                    sender.sendMessage("§cNincs jogod /cw reload használatához.");
                    return true;
                }
                storage.loadAllAsync(() -> {
                    weaponService.loadWeaponsIntoMemory();
                    sender.sendMessage("§aCustomWeaponsPlus újratöltve.");
                });
                return true;

            default:
                sender.sendMessage("§cIsmeretlen alparancs: " + sub);
                return true;
        }
    }
}

package hu.david.customweapons.storage;

import hu.david.customweapons.data.PlayerData;
import hu.david.customweapons.WeaponDefinition;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * YamlStorage — aszinkron YAML I/O réteg.
 *
 * Kezeli a weapons.yml (összes WeaponDefinition) és per-player YAML fájlok
 * beolvasását/mentését. Az írások aszinkron végzik, atomikus mentéssel
 * (temp file + rename) a korrupció elkerülésére.
 */
public class YamlStorage {

    private final JavaPlugin plugin;
    private final Path dataFolder;
    private final Path playersFolder;
    private final Path weaponsFile;

    private final ExecutorService ioExecutor;
    private final Yaml yaml;

    // Memóriában tárolt per-player adatok (runtime cache)
    private final ConcurrentMap<UUID, PlayerData> playerCache = new ConcurrentHashMap<>();

    // Memóriában betöltött weapon definíciók (map id -> def) — ez is elérhető a WeaponService számára
    private final ConcurrentMap<String, WeaponDefinition> weaponMap = new ConcurrentHashMap<>();

    public YamlStorage(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFolder = plugin.getDataFolder().toPath().resolve("data");
        this.playersFolder = dataFolder.resolve("players");
        this.weaponsFile = dataFolder.resolve("weapons.yml");

        this.ioExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "CustomWeaponsPlus-IO");
            t.setDaemon(true);
            return t;
        });

        DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        options.setPrettyFlow(true);
        this.yaml = new Yaml(options);

        // Ensure folders exist (sync is fine here at startup)
        try {
            Files.createDirectories(playersFolder);
            if (!Files.exists(weaponsFile)) {
                // create an empty weapons.yml skeleton if missing
                Map<String, Object> root = new LinkedHashMap<>();
                root.put("weapons", Collections.emptyList());
                try (Writer w = Files.newBufferedWriter(weaponsFile, StandardOpenOption.CREATE_NEW)) {
                    yaml.dump(root, w);
                }
            }
        } catch (IOException e) {
            plugin.getLogger().severe("Nem sikerült adat mappát létrehozni: " + e.getMessage());
        }
    }

    /**
     * Aszinkron teljes betöltés (weapons + per-player fájlok meta betöltése).
     * A callback a főszálon fut le.
     */
    public void loadAllAsync(Runnable onCompleteMainThread) {
        ioExecutor.submit(() -> {
            try {
                loadWeaponsSync();
                // Per-player fájlok lazy betöltése (nem töltünk be minden játékost memóriába),
                // de itt felmérjük a mappát, hogy létezik-e.
            } catch (Exception e) {
                plugin.getLogger().severe("Hiba YAML betöltés során: " + e.getMessage());
            } finally {
                // callback a main thread-en
                Bukkit.getScheduler().runTask(plugin, onCompleteMainThread);
            }
        });
    }

    /**
     * Szinkron fegyverek betöltése - belső használatra (IO thread).
     */
    @SuppressWarnings("unchecked")
    private void loadWeaponsSync() {
        try (InputStream in = Files.newInputStream(weaponsFile);
             Reader reader = new InputStreamReader(in)) {
            Object loaded = yaml.load(reader);
            if (!(loaded instanceof Map)) return;
            Map<String, Object> root = (Map<String, Object>) loaded;
            Object wlist = root.get("weapons");
            if (wlist instanceof List) {
                List<Map<String, Object>> list = (List<Map<String, Object>>) wlist;
                for (Map<String, Object> m : list) {
                    WeaponDefinition wd = WeaponDefinition.fromMap((Map<String, Object>) m);
                    if (wd.getId() != null) {
                        weaponMap.put(wd.getId(), wd);
                    }
                }
            }
            plugin.getLogger().info("weapons.yml betöltve, keret: " + weaponMap.size() + " fegyver.");
        } catch (IOException e) {
            plugin.getLogger().severe("Hiba weapons.yml olvasásakor: " + e.getMessage());
        }
    }

    /**
     * Memóriában lévő fegyverek visszaadása.
     */
    public Map<String, WeaponDefinition> getWeaponMap() {
        return Collections.unmodifiableMap(weaponMap);
    }

    /**
     * Mentés (aszinkron) a weapons.yml fájlba. Callback a main thread-en fut.
     */
    public void saveWeaponsAsync(Runnable onComplete) {
        Map<String, WeaponDefinition> snapshot = new LinkedHashMap<>(weaponMap);
        ioExecutor.submit(() -> {
            try {
                // Build a serializable list
                List<Map<String, Object>> list = new ArrayList<>();
                for (WeaponDefinition w : snapshot.values()) {
                    list.add(w.toMap());
                }
                Map<String, Object> root = new LinkedHashMap<>();
                root.put("weapons", list);
                atomicWriteYaml(weaponsFile, root);
            } catch (Exception e) {
                plugin.getLogger().severe("Hiba weapons.yml mentésekor: " + e.getMessage());
            } finally {
                if (onComplete != null) {
                    Bukkit.getScheduler().runTask(plugin, onComplete);
                }
            }
        });
    }

    /**
     * Per-player fájl beolvasása (synchronus IO, de meghívjuk aszinkron metódusból).
     */
    public PlayerData loadPlayerSync(UUID uuid) {
        Path p = playersFolder.resolve(uuid.toString() + ".yml");
        if (!Files.exists(p)) {
            PlayerData pd = PlayerData.createEmpty(uuid);
            playerCache.put(uuid, pd);
            return pd;
        }
        try (InputStream in = Files.newInputStream(p);
             Reader reader = new InputStreamReader(in)) {
            Object loaded = yaml.load(reader);
            if (loaded instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> root = (Map<String, Object>) loaded;
                PlayerData pd = PlayerData.fromMap(root);
                playerCache.put(uuid, pd);
                return pd;
            }
        } catch (IOException e) {
            plugin.getLogger().severe("Hiba per-player fájl beolvasásakor: " + e.getMessage());
        }
        PlayerData pd = PlayerData.createEmpty(uuid);
        playerCache.put(uuid, pd);
        return pd;
    }

    /**
     * Aszinkron per-player load (ha nincs memóriában, betöltjük).
     * A callback a main thread-en fut és kapja a PlayerData-t.
     */
    public void loadPlayerAsync(UUID uuid, java.util.function.Consumer<PlayerData> callback) {
        PlayerData cached = playerCache.get(uuid);
        if (cached != null) {
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(cached));
            return;
        }
        ioExecutor.submit(() -> {
            PlayerData pd = loadPlayerSync(uuid);
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(pd));
        });
    }

    /**
     * Aszinkron per-player mentés (memória -> disk). Callback a main thread-en fut.
     */
    public void savePlayerAsync(UUID uuid, Runnable onComplete) {
        PlayerData pd = playerCache.get(uuid);
        if (pd == null) {
            if (onComplete != null) Bukkit.getScheduler().runTask(plugin, onComplete);
            return;
        }
        ioExecutor.submit(() -> {
            try {
                Map<String, Object> map = pd.toMap();
                Path p = playersFolder.resolve(uuid.toString() + ".yml");
                atomicWriteYaml(p, map);
            } catch (Exception e) {
                plugin.getLogger().severe("Hiba per-player mentésekor: " + e.getMessage());
            } finally {
                if (onComplete != null) Bukkit.getScheduler().runTask(plugin, onComplete);
            }
        });
    }

    /**
     * Mentés az összes memóriában lévő per-player adatból (pl. shutdown).
     */
    public void saveAllPlayersAsync(Runnable onComplete) {
        // Snapshot keys to avoid concurrent modification issues
        List<UUID> uuids = new ArrayList<>(playerCache.keySet());
        CountDownLatch latch = new CountDownLatch(uuids.size());
        for (UUID u : uuids) {
            savePlayerAsync(u, () -> latch.countDown());
        }
        ioExecutor.submit(() -> {
            try {
                latch.await(10, TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {}
            if (onComplete != null) Bukkit.getScheduler().runTask(plugin, onComplete);
        });
    }

    /**
     * Atomikus YAML írás: ideiglenes fájlba írunk, majd átnevezünk.
     */
    private void atomicWriteYaml(Path target, Object data) throws IOException {
        Path parent = target.getParent();
        if (!Files.exists(parent)) Files.createDirectories(parent);
        Path tmp = Files.createTempFile(parent, "tmp-", ".yml");
        try (Writer w = Files.newBufferedWriter(tmp, StandardOpenOption.TRUNCATE_EXISTING)) {
            yaml.dump(data, w);
            w.flush();
        }
        // Try atomic move, fallback to replace
        try {
            Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException ex) {
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}

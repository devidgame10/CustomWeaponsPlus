package hu.david.customweapons.service;

import hu.david.customweapons.WeaponDefinition;
import hu.david.customweapons.data.PlayerData;
import hu.david.customweapons.storage.YamlStorage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * WeaponService — magas szintű API a fegyverek kezeléséhez.
 *
 * - Betölti a WeaponDefinition-öket a YamlStorage-ból (memória snapshot).
 * - Készít ItemStack-et WeaponFactory segítségével.
 * - Kezeli a /cw give működését (memória + per-player állapot frissítése).
 */
public class WeaponService {

    private final JavaPlugin plugin;
    private final YamlStorage storage;
    private final WeaponFactory factory;

    // Gyors snapshot a weapon definíciókról (id -> def)
    private final Map<String, WeaponDefinition> weapons = new ConcurrentHashMap<>();

    public WeaponService(JavaPlugin plugin, YamlStorage storage) {
        this.plugin = plugin;
        this.storage = storage;
        this.factory = new WeaponFactory(plugin);
    }

    /**
     * Betölti a weapons-t a storage memóriamapjából a service lokális cache-ébe.
     */
    public void loadWeaponsIntoMemory() {
        weapons.clear();
        weapons.putAll(storage.getWeaponMap());
        plugin.getLogger().info("WeaponService betöltött " + weapons.size() + " fegyvert.");
    }

    /**
     * Give parancs implementáció: a játékosnak ad egy ItemStack-et a weaponId alapján,
     * frissíti a per-player állapotot is memóriában, majd aszinkron menti.
     *
     * @param giver Executor (pl. plugin log)
     * @param target Player akinek adunk
     * @param weaponId fegyver azonosító
     * @param count darab
     * @return true ha sikeres, false ha nem található weaponId
     */
    public boolean giveWeapon(String giver, Player target, String weaponId, int count) {
        WeaponDefinition def = weapons.get(weaponId);
        if (def == null) return false;

        ItemStack item = factory.createItem(def);
        item.setAmount(Math.max(1, Math.min(64, count)));

        target.getInventory().addItem(item);

        // Per-player állapot frissítése (durability, uses increment)
        UUID uuid = target.getUniqueId();
        storage.loadPlayerAsync(uuid, pd -> {
            // Ha nincs entry, létrehozza
            pd.ensureWeaponEntry(weaponId);
            pd.setDurability(weaponId, def.getDurability());
            pd.incrementUses(weaponId, count);
            // Aszinkron mentés (nem blokkoljuk a parancsot)
            storage.savePlayerAsync(uuid, () -> {
                plugin.getLogger().fine("Per-player állapot mentve: " + uuid + " -> " + weaponId);
            });
        });

        return true;
    }

    /**
     * Fegyver definíció lekérése id alapján.
     */
    public WeaponDefinition getWeapon(String id) {
        return weapons.get(id);
    }

    /**
     * Visszaadja a WeaponFactory példányt (pl. eseménykezelők használhatják).
     */
    public WeaponFactory getFactory() {
        return factory;
    }

    /**
     * Frissíti a service-ben lévő definíciót és mentésre jelöli a weapons.yml-t.
     */
    public void updateWeaponAndSave(WeaponDefinition def) {
        weapons.put(def.getId(), def);
        // Frissítjük a yaml storage memóriáját is
        // storage.getWeaponMap() visszaadása unmodifiable map, de korábbi kódban feltételeztük mutálható
        // helyesebb megoldás: call saveWeaponsAsync with snapshot from this service
        storage.saveWeaponsAsync(null);
    }
}

package hu.david.customweapons.service;

import hu.david.customweapons.WeaponDefinition;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

/**
 * WeaponFactory — létrehozza az ItemStack-eket egy WeaponDefinition alapján.
 * A létrehozott ItemStack tartalmazni fog egy persistent data kulcsot (cw:weapon_id),
 * CustomModelData-t (ha meg van adva) és egy alap lore-t.
 */
public class WeaponFactory {

    private final JavaPlugin plugin;
    private final NamespacedKey keyWeaponId;

    public WeaponFactory(JavaPlugin plugin) {
        this.plugin = plugin;
        this.keyWeaponId = new NamespacedKey(plugin, "weapon_id");
    }

    /**
     * Létrehoz egy ItemStack-et a WeaponDefinition alapján.
     * Jelenleg egyszerű item-materialt (DIAMOND_SWORD) használunk template-ként,
     * később lehet template alapján változtatni (pl. configban megadott baseMaterial).
     *
     * @param def WeaponDefinition
     * @return ItemStack reprezentáció a játékosnak
     */
    public ItemStack createItem(WeaponDefinition def) {
        // Egyszerű alap-item — később lehet, hogy baseMaterial mező lesz a def-ben
        ItemStack item = new ItemStack(org.bukkit.Material.DIAMOND_SWORD, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        // Display név
        meta.setDisplayName(def.getDisplayName() != null ? def.getDisplayName() : def.getId());

        // CustomModelData támogatás
        if (def.getCustomModelData() != null) {
            meta.setCustomModelData(def.getCustomModelData());
        }

        // PersistentData: cw:weapon_id = id
        meta.getPersistentDataContainer().set(keyWeaponId, PersistentDataType.STRING, def.getId());

        // Lore alap információk (ritkaság, sebzés, durability)
        List<String> lore = new ArrayList<>();
        lore.add("§7Rarity: §f" + (def.getRarity() != null ? def.getRarity().name() : "UNKNOWN"));
        lore.add(String.format("§7Damage: §f%.2f", def.getBaseDamage()));
        lore.add(String.format("§7Attack speed modifier: §f%.2f", def.getAttackSpeedModifier()));
        if (def.getDurability() > 0) {
            lore.add("§7Durability: §f" + def.getDurability());
        } else {
            lore.add("§7Durability: §f—");
        }

        // Speciális képességek rövid leírása lore-ként
        if (def.getSpecialAbilities() != null) {
            for (var a : def.getSpecialAbilities()) {
                Object name = a.get("name");
                Object params = a.get("params");
                lore.add("§6Ability: §e" + (name != null ? name.toString() : "unknown") + (params != null ? " " + params.toString() : ""));
            }
        }

        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Segédfüggvény: ha ItemStack tartalmazza a plugin által beállított weapon_id-t,
     * visszaadja azt; különben null.
     */
    public String getWeaponIdFromItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        var meta = item.getItemMeta();
        if (meta == null) return null;
        return meta.getPersistentDataContainer().get(keyWeaponId, PersistentDataType.STRING);
    }
}

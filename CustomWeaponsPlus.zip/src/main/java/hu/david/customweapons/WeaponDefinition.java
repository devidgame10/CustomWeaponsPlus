package hu.david.customweapons;

import java.util.*;

/**
 * WeaponDefinition - leíró osztály egyedi fegyverekhez.
 *
 * Tartalmazza az alap attribútumokat (id, név, rarity, sebzés, támadási sebesség módosító,
 * tartósság), CustomModelData támogatást és speciális képességek listáját.
 *
 * Ez az osztály használható YAML (pl. SnakeYAML) szerializációhoz és betöltéshez.
 */
public class WeaponDefinition {

    /**
     * Fegyver azonosító (egyedi, config-ban hivatkozható).
     */
    private String id;

    /**
     * Játékbeli megjelenítendő név.
     */
    private String displayName;

    /**
     * Ritkaság: COMMON / RARE / EPIC / LEGENDARY
     */
    private Rarity rarity;

    /**
     * Alap sebzés (például 6.0 = 3 szív).
     */
    private double baseDamage;

    /**
     * Támadási sebesség módosító (alap 1.0)
     */
    private double attackSpeedModifier;

    /**
     * Tartósság (durability). Ha 0 vagy negatív => nincs korlátozva.
     */
    private int durability;

    /**
     * Egyedi model adat (van-e CustomModelData érték).
     * Ha null => nincs megadva.
     */
    private Integer customModelData;

    /**
     * Speciális képességek listája (pl. lifesteal, damageBoost, chargeAttack).
     * Egyszerű kulcs-érték párok (drótvázként: name -> param map).
     */
    private List<Map<String, Object>> specialAbilities = new ArrayList<>();

    /**
     * Üres konstruktor a YAML deserializációhoz.
     */
    public WeaponDefinition() {}

    /**
     * Teljes konstruktor.
     */
    public WeaponDefinition(String id, String displayName, Rarity rarity, double baseDamage,
                            double attackSpeedModifier, int durability, Integer customModelData) {
        this.id = id;
        this.displayName = displayName;
        this.rarity = rarity;
        this.baseDamage = baseDamage;
        this.attackSpeedModifier = attackSpeedModifier;
        this.durability = durability;
        this.customModelData = customModelData;
    }

    // --- Getterek és Setterek ---

    public String getId() {
        return id;
    }

    public WeaponDefinition setId(String id) {
        this.id = id;
        return this;
    }

    public String getDisplayName() {
        return displayName;
    }

    public WeaponDefinition setDisplayName(String displayName) {
        this.displayName = displayName;
        return this;
    }

    public Rarity getRarity() {
        return rarity;
    }

    public WeaponDefinition setRarity(Rarity rarity) {
        this.rarity = rarity;
        return this;
    }

    public double getBaseDamage() {
        return baseDamage;
    }

    public WeaponDefinition setBaseDamage(double baseDamage) {
        this.baseDamage = baseDamage;
        return this;
    }

    public double getAttackSpeedModifier() {
        return attackSpeedModifier;
    }

    public WeaponDefinition setAttackSpeedModifier(double attackSpeedModifier) {
        this.attackSpeedModifier = attackSpeedModifier;
        return this;
    }

    public int getDurability() {
        return durability;
    }

    public WeaponDefinition setDurability(int durability) {
        this.durability = durability;
        return this;
    }

    public Integer getCustomModelData() {
        return customModelData;
    }

    public WeaponDefinition setCustomModelData(Integer customModelData) {
        this.customModelData = customModelData;
        return this;
    }

    public List<Map<String, Object>> getSpecialAbilities() {
        return specialAbilities;
    }

    public WeaponDefinition setSpecialAbilities(List<Map<String, Object>> specialAbilities) {
        this.specialAbilities = specialAbilities;
        return this;
    }

    /**
     * Kényelmi metódus egy képesség hozzáadásához.
     * @param name képesség neve (pl. lifesteal)
     * @param params paramétertér (pl. amount:4)
     */
    public WeaponDefinition addAbility(String name, Map<String, Object> params) {
        Map<String, Object> m = new HashMap<>();
        m.put("name", name);
        m.put("params", params);
        this.specialAbilities.add(m);
        return this;
    }

    /**
     * Enum az egyszerű ritkaság kezeléséhez.
     */
    public enum Rarity {
        COMMON,
        RARE,
        EPIC,
        LEGENDARY
    }

    @Override
    public String toString() {
        return "WeaponDefinition{" +
                "id='" + id + '\'' +
                ", displayName='" + displayName + '\'' +
                ", rarity=" + rarity +
                ", baseDamage=" + baseDamage +
                ", attackSpeedModifier=" + attackSpeedModifier +
                ", durability=" + durability +
                ", customModelData=" + customModelData +
                ", specialAbilities=" + specialAbilities +
                '}';
    }

    /**
     * Segédfüggvény: konvertálás Map-re (YAML íráshoz kényelmes).
     */
    public Map<String, Object> toMap() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", id);
        map.put("displayName", displayName);
        map.put("rarity", rarity != null ? rarity.name() : null);
        map.put("baseDamage", baseDamage);
        map.put("attackSpeedModifier", attackSpeedModifier);
        map.put("durability", durability);
        map.put("customModelData", customModelData);
        map.put("specialAbilities", specialAbilities);
        return map;
    }

    /**
     * Egyszerű factory módszer YAML-ből való kézi deserializationhoz (ha szükséges).
     */
    @SuppressWarnings("unchecked")
    public static WeaponDefinition fromMap(Map<String, Object> map) {
        WeaponDefinition w = new WeaponDefinition();
        w.setId((String) map.get("id"));
        w.setDisplayName((String) map.get("displayName"));
        Object r = map.get("rarity");
        if (r != null) {
            w.setRarity(Rarity.valueOf(((String) r).toUpperCase()));
        }
        Object bd = map.get("baseDamage");
        if (bd instanceof Number) {
            w.setBaseDamage(((Number) bd).doubleValue());
        }
        Object as = map.get("attackSpeedModifier");
        if (as instanceof Number) {
            w.setAttackSpeedModifier(((Number) as).doubleValue());
        }
        Object d = map.get("durability");
        if (d instanceof Number) {
            w.setDurability(((Number) d).intValue());
        }
        Object cmd = map.get("customModelData");
        if (cmd instanceof Number) {
            w.setCustomModelData(((Number) cmd).intValue());
        }
        Object sa = map.get("specialAbilities");
        if (sa instanceof List) {
            w.setSpecialAbilities((List<Map<String, Object>>) sa);
        }
        return w;
    }
}

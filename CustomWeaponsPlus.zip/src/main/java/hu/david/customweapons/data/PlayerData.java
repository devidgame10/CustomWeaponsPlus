package hu.david.customweapons.data;

import java.util.*;

/**
 * PlayerData — egyszerű reprezentáció a per-player YAML fájlhoz.
 *
 * A strukturált mezők: uuid, lastSeen (ISO string), weapons -> map(weaponId -> weaponState)
 * weaponState tartalmazhat: durability (int), uses (int), cooldowns (map ability -> epoch ms)
 *
 * Egyszerű Map alapú implementáció a YAML serializációhoz.
 */
public class PlayerData {

    private UUID uuid;
    private String lastSeen;
    private final Map<String, Map<String, Object>> weapons = new LinkedHashMap<>();

    private PlayerData() {}

    public static PlayerData createEmpty(UUID uuid) {
        PlayerData pd = new PlayerData();
        pd.uuid = uuid;
        pd.lastSeen = java.time.Instant.now().toString();
        return pd;
    }

    @SuppressWarnings("unchecked")
    public static PlayerData fromMap(Map<String, Object> map) {
        PlayerData pd = new PlayerData();
        Object u = map.get("uuid");
        if (u instanceof String) {
            pd.uuid = UUID.fromString((String) u);
        }
        Object ls = map.get("lastSeen");
        pd.lastSeen = ls instanceof String ? (String) ls : java.time.Instant.now().toString();
        Object w = map.get("weapons");
        if (w instanceof Map) {
            Map<String, Object> wm = (Map<String, Object>) w;
            for (Map.Entry<String, Object> e : wm.entrySet()) {
                if (e.getValue() instanceof Map) {
                    pd.weapons.put(e.getKey(), new LinkedHashMap<>((Map<String, Object>) e.getValue()));
                }
            }
        }
        return pd;
    }

    public Map<String, Object> toMap() {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("uuid", uuid != null ? uuid.toString() : null);
        root.put("lastSeen", lastSeen);
        root.put("weapons", weapons);
        return root;
    }

    // --- Segédfüggvények a fegyver állapot kezeléséhez ---

    /**
     * Biztosítja, hogy legyen entry a fegyverhez.
     */
    public void ensureWeaponEntry(String weaponId) {
        weapons.computeIfAbsent(weaponId, k -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("durability", 0);
            m.put("uses", 0);
            m.put("cooldowns", new LinkedHashMap<String, Long>());
            return m;
        });
    }

    public void setDurability(String weaponId, int durability) {
        ensureWeaponEntry(weaponId);
        weapons.get(weaponId).put("durability", durability);
    }

    public Integer getDurability(String weaponId) {
        ensureWeaponEntry(weaponId);
        Object v = weapons.get(weaponId).get("durability");
        if (v instanceof Number) return ((Number) v).intValue();
        return null;
    }

    public void incrementUses(String weaponId, int delta) {
        ensureWeaponEntry(weaponId);
        Object v = weapons.get(weaponId).get("uses");
        int cur = v instanceof Number ? ((Number) v).intValue() : 0;
        weapons.get(weaponId).put("uses", cur + delta);
    }

    @SuppressWarnings("unchecked")
    public Map<String, Long> getCooldowns(String weaponId) {
        ensureWeaponEntry(weaponId);
        Object c = weapons.get(weaponId).get("cooldowns");
        if (c instanceof Map) {
            Map<String, Long> out = new LinkedHashMap<>();
            Map<?, ?> m = (Map<?, ?>) c;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                String key = String.valueOf(e.getKey());
                Long val = null;
                Object ov = e.getValue();
                if (ov instanceof Number) val = ((Number) ov).longValue();
                else if (ov instanceof String) {
                    try { val = Long.parseLong((String) ov); } catch (NumberFormatException ignore) {}
                }
                out.put(key, val != null ? val : 0L);
            }
            return out;
        } else {
            Map<String, Long> newMap = new LinkedHashMap<>();
            weapons.get(weaponId).put("cooldowns", newMap);
            return newMap;
        }
    }

    @SuppressWarnings("unchecked")
    public void setCooldown(String weaponId, String abilityName, long epochMs) {
        ensureWeaponEntry(weaponId);
        Map<String, Long> cds = (Map<String, Long>) weapons.get(weaponId).get("cooldowns");
        if (cds == null) {
            cds = new LinkedHashMap<>();
            weapons.get(weaponId).put("cooldowns", cds);
        }
        cds.put(abilityName, epochMs);
    }

    public UUID getUuid() {
        return uuid;
    }
}

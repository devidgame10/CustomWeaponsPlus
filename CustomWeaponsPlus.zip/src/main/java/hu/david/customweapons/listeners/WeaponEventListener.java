package hu.david.customweapons.listeners;

import hu.david.customweapons.WeaponDefinition;
import hu.david.customweapons.data.PlayerData;
import hu.david.customweapons.service.WeaponService;
import hu.david.customweapons.storage.YamlStorage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;

/**
 * WeaponEventListener — eseménykezelő a fegyverek mechanikáihoz.
 *
 * Jelenleg kezeli:
 * - lifesteal (ability név alapján, cooldown-okkal)
 * - critChance (egyszerű eséllyel extra multipliert ad)
 *
 * A pontos paramétereket a WeaponDefinition.specialAbilities tartalmazza.
 */
public class WeaponEventListener implements Listener {

    private final JavaPlugin plugin;
    private final WeaponService weaponService;
    private final YamlStorage storage;

    public WeaponEventListener(JavaPlugin plugin, WeaponService weaponService, YamlStorage storage) {
        this.plugin = plugin;
        this.weaponService = weaponService;
        this.storage = storage;
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent ev) {
        Entity damager = ev.getDamager();
        if (!(damager instanceof Player)) return;
        Player attacker = (Player) damager;
        // Kézben lévő tárgyból kinyerjük a weapon id-t
        var item = attacker.getInventory().getItemInMainHand();
        String weaponId = weaponService.getFactory().getWeaponIdFromItem(item);
        if (weaponId == null) return;

        WeaponDefinition def = weaponService.getWeapon(weaponId);
        if (def == null) return;

        // Alap sebzés: event set
        double base = def.getBaseDamage();
        // egyszerűen hozzáadjuk a baseDamage-ot az eseményhez (nem cseréljük teljesen)
        // itt csak egy példa: növeljük a damage értéket a baseDamage - placeholder logika
        ev.setDamage(ev.getDamage() + base / 2.0);

        // Betöltjük a per-player adatot (sync: load from cache or async if missing)
        storage.loadPlayerAsync(attacker.getUniqueId(), pd -> {
            long now = System.currentTimeMillis();

            // Iterate abilities
            if (def.getSpecialAbilities() != null) {
                for (Map<String, Object> a : def.getSpecialAbilities()) {
                    Object nameObj = a.get("name");
                    if (nameObj == null) continue;
                    String name = nameObj.toString();
                    @SuppressWarnings("unchecked")
                    Map<String, Object> params = (Map<String, Object>) a.get("params");

                    switch (name) {
                        case "lifesteal":
                            handleLifesteal(attacker, ev, def, pd, params, now);
                            break;
                        case "critChance":
                            handleCritChance(attacker, ev, def, pd, params, now);
                            break;
                        // további ability-k (chargeAttack, damageBoost stb.) később
                        default:
                            break;
                    }
                }
            }

            // Mentjük a per-player állapotot aszinkron (például ha cooldown változott)
            storage.savePlayerAsync(attacker.getUniqueId(), null);
        });
    }

    /**
     * Lifesteal implementáció:
     * - params: min (hp), max (hp), cooldown_ms
     */
    private void handleLifesteal(Player attacker, EntityDamageByEntityEvent ev, WeaponDefinition def,
                                 PlayerData pd, Map<String, Object> params, long now) {
        if (params == null) return;
        int min = params.get("min") instanceof Number ? ((Number) params.get("min")).intValue() : 1;
        int max = params.get("max") instanceof Number ? ((Number) params.get("max")).intValue() : min;
        long cooldownMs = params.get("cooldown_ms") instanceof Number ? ((Number) params.get("cooldown_ms")).longValue() : 5000L;

        Map<String, Long> cds = pd.getCooldowns(def.getId());
        long last = cds.getOrDefault("lifesteal", 0L);
        if (now < last) return; // még cooldown alatt

        // Sebzés mértéke alapján kiszámolhatjuk a gyógyítást (konkrét egyszerű szám: random min-max)
        int heal = min + (int) (Math.random() * (max - min + 1));
        double finalHeal = Math.max(0.0, Math.min(20.0, heal)); // korlátozás a játékélményért

        // Alkalmazzuk a gyógyítást (főszálon)
        int finalHealInt = (int) finalHeal;
        Bukkit.getScheduler().runTask(plugin, () -> {
            double newHealth = Math.min(attacker.getMaxHealth(), attacker.getHealth() + finalHealInt);
            attacker.setHealth(newHealth);
            attacker.sendMessage("§aLifesteal! §f+" + finalHealInt + " HP");
        });

        // Mentjük a cooldown-t a player data-ba
        pd.setCooldown(def.getId(), "lifesteal", now + cooldownMs);
    }

    /**
     * Kritikus találat implementáció:
     * - params: chance_percent (double), multiplier (double), cooldown_ms
     */
    private void handleCritChance(Player attacker, EntityDamageByEntityEvent ev, WeaponDefinition def,
                                  PlayerData pd, Map<String, Object> params, long now) {
        if (params == null) return;
        double chance = params.get("chance_percent") instanceof Number ? ((Number) params.get("chance_percent")).doubleValue() : 0.0;
        double multiplier = params.get("multiplier") instanceof Number ? ((Number) params.get("multiplier")).doubleValue() : 1.0;
        long cooldownMs = params.get("cooldown_ms") instanceof Number ? ((Number) params.get("cooldown_ms")).longValue() : 0L;

        Map<String, Long> cds = pd.getCooldowns(def.getId());
        long last = cds.getOrDefault("critChance", 0L);
        if (now < last) return; // cooldown alatt

        double roll = Math.random() * 100.0;
        if (roll <= chance) {
            // alkalmazzuk a kritikus multipliert
            double old = ev.getDamage();
            ev.setDamage(old * multiplier);
            pd.setCooldown(def.getId(), "critChance", now + cooldownMs);
            attacker.sendMessage("§cKritikus találat! §fx" + multiplier);
        }
    }
}

# CustomWeaponsPlus (Full Project - Milestone 1)

Ez a csomag tartalmazza az 1. mérföldkőhöz szükséges forrásokat: `pom.xml`, minimális Java forrás, `plugin.yml`, példa YAML fájlok, resourcepack template és GitHub Actions workflow a JAR buildhez.

**Gyors telepítés (ajánlott):** Töltsd fel a teljes mappát egy GitHub repo-ba és indítsd el az Actions workflow-ot (lásd `.github/workflows/build.yml`). Az Action lefordítja és feltölti a `target/*.jar` artifactet, amit letölthetsz és a `plugins/` mappába másolhatsz.
